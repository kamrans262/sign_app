import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sign2digital/features/quotes/domain/quote_draft_input.dart';
import 'package:sign2digital/features/quotes/domain/quote_extraction_models.dart';
import 'package:sign2digital/features/quotes/domain/quote_preparation_service.dart';
import 'package:sign2digital/features/quotes/presentation/screens/quote_ai_processing_screen.dart';
import 'package:sign2digital/features/quotes/presentation/screens/create_quote_screen.dart';

class _FakeService implements QuotePreparationService {
  final controller = StreamController<QuotePreparationSnapshot>.broadcast();
  @override
  Stream<QuotePreparationSnapshot> prepare(QuoteDraftInput input) => controller.stream;
  Future<void> dispose() => controller.close();
}

final sampleInput = QuoteDraftInput(
  method: QuoteInputMethod.text,
  description: 'Install three windows.',
  clientId: 'test-client',
  createdAt: DateTime(2026, 10, 12),
);

void main() {
  test('quote illustration source exists and pubspec registers it', () async {
    final bytes = await File('assets/create_quote.png').readAsBytes();
    expect(bytes.length, greaterThan(1024));
    final spec = await File('pubspec.yaml').readAsString();
    expect(spec.contains('assets/create_quote.png'), isTrue);
  });

  testWidgets('processing page references quote illustration', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: QuoteAiProcessingScreen()));
    expect(find.byKey(const Key('create-quote-illustration')), findsOneWidget);
  });

  testWidgets('No service does not invent extracted data or progress', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: QuoteAiProcessingScreen()));
    expect(find.textContaining('AI quote generation is not connected yet'), findsOneWidget);
    expect(find.text('3 windows'), findsNothing);
    expect(find.byKey(const Key('quote-processing-progress')), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Figma example is explicitly labelled as demonstration', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: QuoteAiProcessingScreen()));
    await tester.ensureVisible(find.byKey(const Key('quote-preview-example')));
    await tester.tap(find.byKey(const Key('quote-preview-example')));
    await tester.pump();
    expect(find.byKey(const Key('quote-demo-label')), findsOneWidget);
    expect(find.text('3 windows'), findsOneWidget);
    expect(find.text('60%'), findsOneWidget);
    expect(find.byKey(const Key('quote-extracted-row-demo-material-a')), findsOneWidget);
    expect(find.byKey(const Key('quote-extracted-row-demo-material-b')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('real service fields and clamped percentage update independently', (tester) async {
    final service = _FakeService();
    addTearDown(service.dispose);
    await tester.pumpWidget(MaterialApp(home: QuoteAiProcessingScreen(
      input: sampleInput, service: service,
    )));
    expect(find.text('3 windows'), findsNothing);
    service.controller.add(const QuotePreparationSnapshot(
      stage: QuotePreparationStage.partial,
      progressPercentage: 110,
      fields: [
        QuoteExtractedField(
          id: 'real-location', label: 'Location',
          value: 'A newly extracted, real address',
          status: QuoteExtractionStatus.needsReview,
        ),
      ],
    ));
    await tester.pump();
    expect(find.text('100%'), findsOneWidget);
    expect(find.text('A newly extracted, real address'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('failed extraction retains partial information for review', (tester) async {
    final service = _FakeService();
    addTearDown(service.dispose);
    await tester.pumpWidget(MaterialApp(home: QuoteAiProcessingScreen(
      input: sampleInput, service: service,
    )));
    service.controller.add(const QuotePreparationSnapshot(
      stage: QuotePreparationStage.partial,
      fields: [QuoteExtractedField(
        id: 'valid-before-fail', label: 'Quantity', value: '7',
        status: QuoteExtractionStatus.needsReview,
      )],
    ));
    await tester.pump();
    service.controller.addError(StateError('Service error'));
    await tester.pump();
    expect(find.text('7'), findsOneWidget);
    expect(find.textContaining('Quote extraction failed'), findsOneWidget);
  });

  testWidgets('long text wraps in phone portrait, landscape and tablet', (tester) async {
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    for (final size in [
      const Size(320, 640),
      const Size(740, 370),
      const Size(1080, 800),
    ]) {
      tester.view.physicalSize = size;
      tester.view.devicePixelRatio = 1;
      await tester.pumpWidget(const MaterialApp(home: QuoteAiProcessingScreen(
        initialSnapshot: QuotePreparationSnapshot(
          stage: QuotePreparationStage.partial,
          progressPercentage: 45,
          fields: [QuoteExtractedField(
            id: 'very-long',
            label: 'Installation details for external fixtures',
            value: 'Removal of old windows, all labour, disposal and necessary safety and weatherproofing precautions for the complete renovation of this building',
            status: QuoteExtractionStatus.unclear,
          )],
        ),
      )));
      await tester.pump();
      expect(tester.takeException(), isNull, reason: 'Failed viewport $size');
    }
    tester.view.resetPhysicalSize();
    tester.view.resetDevicePixelRatio();
  });

  testWidgets('Create Quote Text Generate Draft opens honest processing page', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: CreateQuoteScreen()));
    await tester.tap(find.byKey(const Key('quote-method-text')));
    await tester.pump();
    await tester.enterText(find.byType(TextFormField),
        'Replace three windows, including removal of old frames');
    await tester.ensureVisible(find.byKey(const Key('quote-generate-draft')));
    await tester.tap(find.byKey(const Key('quote-generate-draft')));
    await tester.pumpAndSettle();
    expect(find.byType(QuoteAiProcessingScreen), findsOneWidget);
    expect(find.textContaining('AI quote generation is not connected yet'), findsOneWidget);
    expect(find.text('3 windows'), findsNothing);
  });
}
